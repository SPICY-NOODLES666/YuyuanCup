#ifndef __CAR_CONTROL_H
#define __CAR_CONTROL_H

#include "main.h"

void Smart_Car_Turn_Left(void);
void Smart_Car_Turn_Left_Weak(void);
void Smart_Car_Turn_Right(void);
void Smart_Car_Turn_Right_Weak(void);
void Smart_Car_Go_Straight(void);
void Smart_Car_Go_Straight_Fast(void);
void Smart_Car_Stop(void);
void Smart_Car_Automatic_Routing(void);
uint8_t Read_CrossLine_Sensors(void);
uint8_t get_current_location(void);
void move_one_step(void);
void move_to_target(uint8_t target_position);
#endif
