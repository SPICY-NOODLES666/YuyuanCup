#include "car_control.h"
#include "tb6612.h"
#include "stm32f1xx_hal_tim.h"
#include "tim.h"
#include <stdio.h>
GPIO_PinState front_line[4];

// Servo parameters definition

#define SERVO_MID_ANGLE   1500  // Servo center angle (straight)
#define SERVO_LEFT_ANGLE  1000  // Maximum left steering angle
#define SERVO_RIGHT_ANGLE 2000   // Maximum right steering angle

// Motor drive parameters
#define BASE_SPEED        -200  // Base driving speed
#define TURN_SPEED        -200  // Turning speed

void Smart_Car_Turn_Left(void)
{
    /* Front wheel steering control */
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,SERVO_LEFT_ANGLE);  // Set maximum left steering angle
    
    /* Rear wheel drive control */
    TB6612_SetPWM_A(TURN_SPEED);       // Right rear wheel
    TB6612_SetPWM_B(TURN_SPEED);       // Left rear wheel (maintain same speed)
}

void Smart_Car_Turn_Left_Weak(void)
{
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,SERVO_LEFT_ANGLE/2); // Half steering angle
    TB6612_SetPWM_A(BASE_SPEED);
    TB6612_SetPWM_B(BASE_SPEED);
}

void Smart_Car_Turn_Right(void)
{
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,SERVO_RIGHT_ANGLE);  // Set maximum right steering angle
    TB6612_SetPWM_A(TURN_SPEED);
    TB6612_SetPWM_B(TURN_SPEED);
}

void Smart_Car_Turn_Right_Weak(void)
{
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,SERVO_RIGHT_ANGLE/2); // Half steering angle
    TB6612_SetPWM_A(BASE_SPEED);
    TB6612_SetPWM_B(BASE_SPEED);
}

void Smart_Car_Go_Straight(void)
{
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,SERVO_MID_ANGLE);    // Reset servo to center
    TB6612_SetPWM_A(BASE_SPEED);        // Constant rear wheel speed
    TB6612_SetPWM_B(BASE_SPEED);
}

void Smart_Car_Go_Straight_Fast(void)
{
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,SERVO_MID_ANGLE);
    TB6612_SetPWM_A(6000);  // Increase rear wheel speed
    TB6612_SetPWM_B(6000);
}

void Smart_Car_Stop(void)
{
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,SERVO_MID_ANGLE);  // Reset steering to center
    TB6612_StopA();                   // Stop rear wheels only
    TB6612_StopB();
}

uint16_t delayTime = 20;
void Smart_Car_Automatic_Routing(void)
{
    front_line[0] = HAL_GPIO_ReadPin(LINE1_GPIO_Port, LINE1_Pin);
    front_line[1] = HAL_GPIO_ReadPin(LINE2_GPIO_Port, LINE2_Pin);
    front_line[2] = HAL_GPIO_ReadPin(LINE3_GPIO_Port, LINE3_Pin);
    front_line[3] = HAL_GPIO_ReadPin(LINE4_GPIO_Port, LINE4_Pin);

    // Modified logic: Control servo angle based on sensor status
    if (front_line[0] == GPIO_PIN_SET && front_line[3] == GPIO_PIN_RESET) 
    {
        Smart_Car_Turn_Left();
        HAL_Delay(delayTime);
    }
    else if (front_line[1] == GPIO_PIN_SET && front_line[2] == GPIO_PIN_RESET)
    {
        Smart_Car_Turn_Left_Weak();
        HAL_Delay(delayTime);
    }
    else if (front_line[3] == GPIO_PIN_SET && front_line[0] == GPIO_PIN_RESET)
    {
        Smart_Car_Turn_Right();
        HAL_Delay(delayTime);
    }
    else if (front_line[2] == GPIO_PIN_SET && front_line[1] == GPIO_PIN_RESET)
    {
        Smart_Car_Turn_Right_Weak();
        HAL_Delay(delayTime);
    }
    else
    {
        Smart_Car_Go_Straight();
    }
}

// ���������߼�⺯��
uint8_t Read_CrossLine_Sensors(void)
{
  uint8_t state = 0;
  state |= HAL_GPIO_ReadPin(LINE1_GPIO_Port, LINE1_Pin) << 4;
  state |= HAL_GPIO_ReadPin(LINE2_GPIO_Port, LINE2_Pin) << 3;
  state |= HAL_GPIO_ReadPin(LINE3_GPIO_Port, LINE3_Pin) << 2;
  state |= HAL_GPIO_ReadPin(LINE4_GPIO_Port, LINE4_Pin) << 1;
		// side sensors
	state |= HAL_GPIO_ReadPin(LINE5_GPIO_Port, LINE5_Pin) << 6;
  state |= HAL_GPIO_ReadPin(LINE6_GPIO_Port, LINE6_Pin) << 5;
  return state;
}

static uint8_t line_counter = 0;  
static uint8_t last_front_line_state = 0;
static uint8_t last_rear_line_state = 0;
static uint8_t moving_flag = 0;  


uint8_t get_current_location()
{
    return line_counter;  
}
void move_one_step()
{
    uint8_t current_line_state = Read_CrossLine_Sensors();
    uint8_t current_front_line_state = current_line_state & 0x40;  //  Line5
    uint8_t current_rear_line_state = current_line_state & 0x20;   //  Line6


    if (current_front_line_state && !last_front_line_state)
    {
        moving_flag = 1;  
        Smart_Car_Automatic_Routing();  
    }

    if (moving_flag && current_rear_line_state && !last_rear_line_state)
    {
        moving_flag = 0;  
        Smart_Car_Stop();  
        
        line_counter++;
				if(line_counter >= 16)
					{
            line_counter = 0;
          }
        printf("Moved one step. Current position: %d\r\n", line_counter);
    }

    last_front_line_state = current_front_line_state;  
    last_rear_line_state = current_rear_line_state;    
}

void move_to_target(uint8_t target_position)
{
		uint8_t current_position = line_counter;
    if (target_position < current_position)
    {
        printf("Target is behind, moving forward to complete one lap.\n");
        while (line_counter != 0)  
        {
            move_one_step();  
						HAL_Delay(200);
        }
        printf("Completed one lap, now proceeding to target.\n");
    }


    while (current_position != target_position)
    {  
        move_one_step();  
				HAL_Delay(200);
    }

    printf("Reached target position: %d\n", target_position);

    printf("Arrived at target position: %d\r\n", target_position);
}
