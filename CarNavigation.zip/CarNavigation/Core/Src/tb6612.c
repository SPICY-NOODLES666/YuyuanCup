#include "tb6612.h"
#include "tim.h"

#define TB6612_A_TIM_Handler htim2
#define TB6612_A_TIM_CHANNEL TIM_CHANNEL_1
#define TB6612_B_TIM_Handler htim2
#define TB6612_B_TIM_CHANNEL TIM_CHANNEL_2


void TB6612_SetPWM_A(int pulse)
{
	if(pulse > 0)
	{
		AIN1_Set();
		AIN2_Clr();
		__HAL_TIM_SET_COMPARE(&TB6612_A_TIM_Handler,TB6612_A_TIM_CHANNEL,pulse);
	}
	else
	{
		AIN1_Clr();
		AIN2_Set();
		__HAL_TIM_SET_COMPARE(&TB6612_A_TIM_Handler,TB6612_A_TIM_CHANNEL,-pulse);
	}
}

void TB6612_StopA(void)
{
		AIN1_Clr();
		AIN2_Clr();
		__HAL_TIM_SET_COMPARE(&TB6612_A_TIM_Handler,TB6612_A_TIM_CHANNEL,0);
}

void TB6612_SetPWM_B(int pulse)
{
	if(pulse > 0)
	{
		BIN1_Set();
		BIN2_Clr();
		__HAL_TIM_SET_COMPARE(&TB6612_B_TIM_Handler,TB6612_B_TIM_CHANNEL,pulse);
	}
	else
	{
		BIN1_Clr();
		BIN2_Set();
		__HAL_TIM_SET_COMPARE(&TB6612_B_TIM_Handler,TB6612_B_TIM_CHANNEL,-pulse);
	}

}

void TB6612_StopB(void)
{
		BIN1_Clr();
		BIN2_Clr();
		__HAL_TIM_SET_COMPARE(&TB6612_B_TIM_Handler,TB6612_B_TIM_CHANNEL,0);
}
