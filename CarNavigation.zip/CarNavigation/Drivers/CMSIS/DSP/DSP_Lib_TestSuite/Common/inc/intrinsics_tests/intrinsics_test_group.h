#ifndef _INTRINSICS_TEST_GROUP_H_
#define _INTRINSICS_TEST_GROUP_H_

/*--------------------------------------------------------------------------------*/
/* Declare Test Groups */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(intrinsics_tests);

#endif /* _INTRINSICS_TEST_GROUP_H_ */
